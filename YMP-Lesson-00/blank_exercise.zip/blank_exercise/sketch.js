function setup(){
  // setup of the sketch
  createCanvas(400,400);
  background(51);
}

function draw(){
  // here you draw to the screen
  fill(255);
  ellipse(200,200,100,100);
}