function neuesElement() {
    /*let div = document.createElement("div");
    div.innerHTML="Need a kick for my mind to bend Experience the randomness How can you understand? Cause baby I don’t."
    div.classList.add('random');
    div.style.left = Math.random() * window.innerWidth + "px";
    div.style.top = Math.random() * window.innerHeight + "px";
    document.body.appendChild(div);*/
}

/*--- Attribute verändern ---*/
//https://www.w3schools.com/jsref/dom_obj_style.asp

/*----alle Random Elemente verändern---*/
//https://developer.mozilla.org/en-US/docs/Web/API/Document/getElementsByName

/*--- Elemente löschen ---*/
//https://developer.mozilla.org/en-US/docs/Web/API/Element/remove