let els = document.getElementsByTagName("a");
    for (let i=0;i<els.length;i++) {
        els[i].addEventListener("click", function(event) {
            event.preventDefault();
            if (event.target.className === 'getImg') { // hier wird gefragt ob sie die Klasse getImg besitzen

                let div = document.createElement('div'); //hier wird ein Div kreiiert
                //hier wird dem div zwei background images zugewiesen. Der Trick ist, den Inhalt vom a über event.target.innerHTML abzufragen und der URL mitzugeben
                div.style.backgroundImage = 'url(https://source.unsplash.com/random/300×300?' + event.target.innerHTML + '&sig=1), url(https://source.unsplash.com/random/300×300?' + event.target.innerHTML + '&sig=2), radial-gradient(rgb(201, 192, 192), rgb(0, 140, 255))';
                //hier wird das CSS konstruiert
                div.style.backgroundPosition = '0 0, 0 50px, 0 0';
                div.style.backgroundBlendMode = 'overlay, screen';
                div.style.backgroundSize = 'cover, cover';
                //hier wird das kreierte div dem a angehängt
                event.target.appendChild(div);
                //hier wird die Klasse getImg entfernt -- sonst würden bei jedem mouseclick event immer neue Bilder hinzugefügt
                event.target.classList.remove("getImg");
                // hier wird der Textstil auf weiss gesetzt 
                event.target.setAttribute("class", "white");
            }

        }, false);
    }