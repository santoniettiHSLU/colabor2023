let n = 0; //keep track of tabs, key for storage
let oldTab = -1;


/******************************************************************
 * Begin Store Screenshot 
/**************************************************************** */
let screenshotToStore = {};

let stored = browser.storage.local.get();
stored.then(onGot, onError);
function onGot(data){
    n = Object.keys(data).length;
}

function onError(error) {
    console.log(`Error: ${error}`);
}

//https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/tabs/onUpdated
/**
 * Fired when a tab is updated.
 */
browser.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {


    if (!tab.url.match(/^127\.0:/)&& !tab.url.match(/^localhost:/) && !tab.url.match(/^about:/) && !tab.url.match(/^moz-extension:/)) {

        let screenshotToStore = {};
        let capturing = browser.tabs.captureVisibleTab();
        capturing.then(onCaptured, onError);

        function onCaptured(imageUri) {
            
                storeScreenshot(imageUri);
                
        }

        function onError(error) {
            console.log(`Error: ${error}`);
        }

        function storeScreenshot(data) {
            
            if (oldTab != tabId) {
                //prevent from storing multiple screenshots of the same tab 
                n++;     
            }
            screenshotToStore[n] = { "screenshot": data, "open": Date.now(), "close": 0, "window": tab.windowId, "url": tab.url, "tabid": tabId };
            browser.storage.local.set(screenshotToStore);
            oldTab = tabId;
        }

    }
});

//close tab, set close timestamp
browser.tabs.onRemoved.addListener(handleRemoved);
let current;


function handleRemoved(tabId, removeInfo) {
    current = tabId;


    let windowId = removeInfo.windowId;

    let storedScreenshots = browser.storage.local.get();

    storedScreenshots.then(onGotSingle, onError);

    function onGotSingle(data) {

        for (const [key, value] of Object.entries(data)) {
            if (parseInt(data[key].tabid) === tabId && parseInt(data[key].window) === windowId && parseInt(data[key].close) == 0) {
                data[key].close = Date.now();
                //console.log(data[key].close);
            }
        }

        browser.storage.local.set(data);
    }






}

//close window, set close timestamp on all tabs associated with this window
browser.windows.onRemoved.addListener((windowId) => {
    closeTabs(windowId);
});

function closeTabs(windowId) {
    let storedScreenshots = browser.storage.local.get();
    storedScreenshots.then(onGot, onError);

    function onGot(data) {

        for (const [key, value] of Object.entries(data)) {
            if (value.window == windowId) {
                data[key].close = Date.now();
            }
        }

        browser.storage.local.set(data);
    }
}

/******************************************************************
 * End Store Screenshot 
 /**************************************************************** */

/**************************************************************** */
/* Open new Tab, show display.html */
/**************************************************************** */

//https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/browserAction/onClicked
/**
 * Fired when a browser action icon is clicked. This event will not fire if the browser action has a popup.
 */
browser.browserAction.onClicked.addListener(() => {
    browser.tabs.create({
        url: browser.runtime.getURL("display.html")
    });

});


