let storedScreenshots = browser.storage.local.get();
storedScreenshots.then(onGot, onError);
let debug=false;

let resultList;



function onGot(data) {
  
    resultList = Object.fromEntries(Object.entries(data).reverse())

    if(debug){
      logData(resultList);
    }
    
    displayData();
}




function displayData() {
 
 let screenshots=Object.entries(resultList);
  for (let s = 0; s < screenshots.length; s++) {
    let value = Object.entries(screenshots[s])[1][1];
    let bitmap = new Image();
    bitmap.src = value.screenshot;
    let div = document.createElement('div');
    bitmap.onload = function () {
      bitmap.style.width = window.innerWidth + "px";
      div.style.backgroundImage = "url('" + bitmap.src + "')";
      div.style.backgroundSize = "100vw 100vh";
      div.style.backgroundRepeat = "repeat-x";
    }

    div.classList.add("screenshot");
    div.style.left=(s*50)+"px";
    

    let url = document.createAttribute("url");
    url.value = value.url;
    div.setAttributeNode(url);

    document.getElementById("wrapper").appendChild(div);
  }


 
}


function onError(error) {
  console.log(`Error: ${error}`);
}


function logData(data){
  console.log(data)
}