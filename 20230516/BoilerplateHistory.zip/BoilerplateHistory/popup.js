// Retrieve the browsing history
browser.history.search({ text: "", startTime: 0, maxResults: 10 })
  .then((historyItems) => {
    const historyList = document.getElementById("historyList");

    //console.log(historyList)

    // Create list items for each history item
    for (const item of historyItems) {
      const listItem = document.createElement("li");
      listItem.textContent = item.title;
      historyList.appendChild(listItem);
    }
  })
  .catch((error) => {
    console.error("Failed to retrieve history:", error);
  });