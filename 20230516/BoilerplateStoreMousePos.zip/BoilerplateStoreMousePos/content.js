
let interval;
let clientX = 0;
let clientY = 0;
let oldX=-1;

document.addEventListener("mousemove", logKey);

function logKey(event) {
   clientX= event.clientX;
   clientY= event.clientY;
}

// Track mouse position at regular intervals (every 1 second)
interval = setInterval(() => {

    console.log(clientX)
    if (clientX != oldX) {
        // Send mouse position to background script
        browser.runtime.sendMessage({ action: "storeMousePosition", position: { x: clientX, y: clientY } });
        oldX = clientX;
    }

}, 1000);