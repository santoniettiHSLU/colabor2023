let positions = [];
let maxLength=100;

// Listen for messages from content script
browser.runtime.onMessage.addListener((message) => {
  
  if (message.action === "storeMousePosition") {
    if(positions.length > maxLength){
        positions.shift();     
    }
    positions.push(message.position);
    //console.log(`Stored mouse position: x=${message.position.x}, y=${message.position.y}`);
  }
});

// Save the stored positions to storage every 10 seconds
setInterval(() => {
  browser.storage.local.set({ positions });
  //console.log(`Stored positions saved to storage: ${positions.length}`);
  
}, 10000);


//https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/browserAction/onClicked
/**
 * Fired when a browser action icon is clicked. This event will not fire if the browser action has a popup.
 */
browser.browserAction.onClicked.addListener(() => {
    console.log("action clicked")
    browser.tabs.create({
        url: browser.runtime.getURL("displayTracks/display.html")
    });

});
