let storedPos = browser.storage.local.get(["positions"]);
storedPos.then(onGot, onError);
//console.log("display script running")




function onGot(data){
    //console.log(data)
    for(let n=0;n<data.positions.length;n++){
        let pos=data.positions[n]; 
        //console.log(pos)
        let myImage = new Image(20, 32);
        myImage.src = "arrow-pointer.svg";
        myImage.style.left=pos.x+"px";
        myImage.style.top=pos.y+"px"

        document.body.appendChild(myImage);
        
    }
}

function onError(error) {
    console.log(`Error: ${error}`);
}